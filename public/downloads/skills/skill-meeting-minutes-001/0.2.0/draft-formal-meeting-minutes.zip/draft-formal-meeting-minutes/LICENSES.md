# Licence and attribution manifest

Package: `draft-formal-meeting-minutes`  
Version: draft 0.2.0  
Status: Licensed for public distribution

| Path | Origin | Licence/status |
| --- | --- | --- |
| `SKILL.md` | Original Forward Academy content | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| `references/template-setup.md` | Original Forward Academy content | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |

No real meeting notes, attendance lists, organisational templates, confidential information, executable files or external dependencies are included.

Users must supply source notes and optional organisational references lawfully and through an AI service approved by their organisation. Adding a user-supplied file does not grant Kemahiran.AI or Forward Academy redistribution rights over that file.

