# Licence and attribution manifest

Package: `generate-dskp-grounded-rph`  
Version: draft 0.4.0  
Status: Licensed for public distribution

| Path | Origin | Licence/status |
| --- | --- | --- |
| `SKILL.md` | Original Forward Academy content | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| `references/knowledge-setup.md` | Original Forward Academy content | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| `references/source-manifest.template.yml` | Original Forward Academy content | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| `references/example-dskp-extract.md` | Original synthetic Forward Academy example | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| `references/sample-input-output.md` | Original synthetic Forward Academy example | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |

No official DSKP PDF, third-party curriculum content, confidential information, executable file or external dependency is included in this draft.

Users must obtain and use reference documents lawfully. Adding a user-supplied document does not grant Kemahiran.AI or Forward Academy redistribution rights over that document.
