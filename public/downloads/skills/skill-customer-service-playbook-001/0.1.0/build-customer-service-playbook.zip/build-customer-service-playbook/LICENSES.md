# Licence and attribution manifest

Package version: 0.1.0  
Status: Licensed for public distribution

| File | Provenance | Licence status |
| --- | --- | --- |
| `SKILL.md` | Original Forward Academy content | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |

No policy, customer record, brand guide or service transcript is bundled.
