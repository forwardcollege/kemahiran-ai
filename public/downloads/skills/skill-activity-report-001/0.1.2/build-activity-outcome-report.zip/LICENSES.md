# Licence and attribution manifest

Package version: 0.1.1  
Status: Licensed for public distribution

| File        | Provenance                                  | Licence status                                            |
| ----------- | ------------------------------------------- | --------------------------------------------------------- |
| `README.md` | Original Forward College (Malaysia) content | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| `SKILL.md`  | Original Forward College (Malaysia) content | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |

No participant record, report source or organisational data is bundled.
