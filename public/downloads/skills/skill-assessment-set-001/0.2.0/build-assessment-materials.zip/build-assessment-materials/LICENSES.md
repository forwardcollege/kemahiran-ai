# Licence and attribution manifest

Package version: 0.2.0  
Status: Licensed for public distribution

| File | Provenance | Licence status |
| --- | --- | --- |
| `SKILL.md` | Original Forward Academy content, curated by Forward Labs | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |

No DSKP PDF, teaching text, examination paper, learner data or third-party asset is bundled. Users must supply sources they are authorised to use at runtime.
